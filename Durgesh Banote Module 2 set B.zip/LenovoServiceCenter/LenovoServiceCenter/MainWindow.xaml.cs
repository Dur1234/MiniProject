﻿using LenovoServiceCenter.BusinessLayer;
using LenovoServiceCenter.Entity;
using LenovoServiceCenter.Exceptions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LenovoServiceCenter
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        ServiceEntity service = new ServiceEntity();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                
                foreach (var item in Enum.GetValues(typeof(DeviceType)))
                {
                    cmbBox1.Items.Add(item);
                }


                ServiceBL pb = new ServiceBL();
                DataTable dt = pb.Display();
                if (dt != null)
                {
                    Datagrid1.ItemsSource = dt.DefaultView;
                }
                else
                {
                    MessageBox.Show("Table is empty", " Lenovo Service Center");
                }
            }
            catch (LenovoServiceException ex)
            {
                MessageBox.Show(ex.Message, "Lenovo Service Center");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Lenovo Service Center");
            }
        }



        private void Button_Click(object sender, RoutedEventArgs e)
        {
            ServiceEntity service = new ServiceEntity()
            {
                ServiceId = txtSerId.Text,
                Date= setDate.DisplayDate,
                Ownername= txtowner.Text,
                ContactNo= txtContact.Text,
                DeviceType= cmbBox1.SelectedValue.ToString(),
                SerialNo= txtSerial.Text,
                IssueDesc = txtDesc.Text
            };

            ServiceBL sbl = new ServiceBL();
            sbl.AddService(service);
            ServiceBL pb = new ServiceBL();
            DataTable dt = pb.Display();
            if (dt != null)
            {
                Datagrid1.ItemsSource = dt.DefaultView;
            }
            else
            {
                MessageBox.Show("Table is empty", " Lenovo Service Center");
            }


        }




        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(txtContact.Text, @"[^0-9]$"))
            {
                MessageBox.Show("This accepts only numeric characters");
                txtContact.Text.Remove(txtContact.Text.Length - 1);
            }

            if (System.Text.RegularExpressions.Regex.IsMatch(txtContact.Text, @"^([789]\d{10}|[0-6]\d*)$"))
            {
                MessageBox.Show("Please enter a valid number...");
                txtContact.Text = txtContact.Text.Remove(txtContact.Text.Length - 1);
            }
        }
    }
}
