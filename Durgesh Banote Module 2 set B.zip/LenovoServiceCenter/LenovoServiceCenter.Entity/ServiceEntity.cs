﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LenovoServiceCenter.Entity
{
    public class ServiceEntity
    {
        public string ServiceId { get; set; }
        public DateTime Date { get; set; }
        public string Ownername { get; set; }
        public string ContactNo { get; set; }
        public string DeviceType { get; set; }
        public string SerialNo { get; set; }
        public string IssueDesc { get; set; }

    }
}
