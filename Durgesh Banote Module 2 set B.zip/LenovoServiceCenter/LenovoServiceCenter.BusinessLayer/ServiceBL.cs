﻿using System;
using System.Data;
using System.Text;
using System.Text.RegularExpressions;
using LenovoServiceCenter.DataAccessLayer;
using LenovoServiceCenter.Entity;
using LenovoServiceCenter.Exceptions;

namespace LenovoServiceCenter.BusinessLayer
{
    public class ServiceBL
    {
        private static bool ValidateGuest(ServiceEntity service)
        {
            StringBuilder sb = new StringBuilder();
            bool validateRequest  = true;

            if ((service.ServiceId == string.Empty) || (service.ServiceId.Length<6 || service.ServiceId.Length>6) || (!service.ServiceId.StartsWith("SR")))
            {
                validateRequest = false;
                sb.Append(Environment.NewLine + "owner Name Required");

            }

            if (service.Ownername == string.Empty)
            {
                validateRequest = false;
                sb.Append(Environment.NewLine + "owner Name Required");

            }

            if ((service.ContactNo.Length < 10 || service.ContactNo.Length > 10) && (service.ContactNo.StartsWith("1") || service.ContactNo.StartsWith("2") || service.ContactNo.StartsWith("3")
                || service.ContactNo.StartsWith("4") || service.ContactNo.StartsWith("5") || service.ContactNo.StartsWith("6") || service.ContactNo.StartsWith("7")))
            {
                validateRequest = false;
                sb.Append(Environment.NewLine + "Required 10 Digit Contact Number");
            }

            if (service.DeviceType == string.Empty)
            {
                validateRequest = false;
                sb.Append(Environment.NewLine + "Device type  required");

            }
            if (!ValidateSerialno(service.SerialNo))
            {
                validateRequest = false;
                sb.Append(Environment.NewLine + "Contact Person name reqired");

            }
            if (service.IssueDesc == string.Empty)
            {
                validateRequest = false;
                sb.Append(Environment.NewLine + "Contact Person name reqired");

            }
            if (validateRequest == false)
                throw new LenovoServiceException(sb.ToString());
            return validateRequest;
        }

        private static bool ValidateSerialno(string serialNo)
        {
            bool b = false; 
            if (!System.Text.RegularExpressions.Regex.IsMatch(serialNo.Trim(), @"^(\d{12}|\d{16})$"))
            {
                b = true;
            }
            return b;
        }

        public bool AddService(ServiceEntity service)
        {
            try
            {
                if (ValidateGuest(service))
                {


                    ServiceDal pd = new ServiceDal();
                    return pd.AddService(service);
                }
            }
            catch (LenovoServiceException)
            {
                throw;
            }
            return true;
        }

        public DataTable Display()
        {
            try
            {
                ServiceDal sd = new ServiceDal();
                return sd.Display();
            }
            catch (LenovoServiceException)
            {
                throw;
            }
        }
    }
}