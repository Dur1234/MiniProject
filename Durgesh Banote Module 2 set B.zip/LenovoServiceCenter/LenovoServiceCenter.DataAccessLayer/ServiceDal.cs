﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using LenovoServiceCenter.Entity;
using LenovoServiceCenter.Exceptions;

namespace LenovoServiceCenter.DataAccessLayer
{
    public class ServiceDal
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="service"></param>
        /// <returns></returns>
        static string conStr = string.Empty;
        SqlConnection con = null;
        SqlCommand cmd = null;



        static ServiceDal()
        {
            conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;

        }

        public ServiceDal()
        {
            con = new SqlConnection(conStr);

        }


        public DataTable Display()
        {
            DataTable dt = null;

            try
            {
                // con = new SqlConnection();
                //con.ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                cmd = new SqlCommand();
                cmd.CommandText = "lenovo.uspGetProducts";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
            }
            catch (LenovoServiceException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return dt;
        }


        public bool AddService(ServiceEntity service)
        {
            bool a= false;

            try
            {
                //con = new SqlConnection();
                //con.ConnectionString = conStr; 
                cmd = new SqlCommand();
                cmd.CommandText = "lenovo.uspAddRequest";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                //cmd.Parameters.Add("@eId", SqlDbType.Int);
                //cmd.Parameters["@eId"].Direction = ParameterDirection.Output;

                cmd.Parameters.AddWithValue("@Id", service.ServiceId);
                cmd.Parameters.AddWithValue("@date", service.Date);
                cmd.Parameters.AddWithValue("@On", service.Ownername);
                cmd.Parameters.AddWithValue("@Cn", service.ContactNo);
                cmd.Parameters.AddWithValue("@Dt", service.DeviceType);
                cmd.Parameters.AddWithValue("@Sn", service.SerialNo);
                cmd.Parameters.AddWithValue("@descp", service.IssueDesc);


                

                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                a = true;
            }
            catch (LenovoServiceException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return a;
        }
    }
}