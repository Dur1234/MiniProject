﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DatabaseApproach
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Training_19Sep18_PuneEntities tr = new Training_19Sep18_PuneEntities();

            Service_Details sd = new Service_Details();

            DbSet<Service_Details> obj = tr.Service_Details;

            var sql = (from m in obj
                      select m.DeviceType).Distinct();

            foreach (var m in sql)
            {
                cmbBox.Items.Add(m);
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Training_19Sep18_PuneEntities tr = new Training_19Sep18_PuneEntities();

            Service_Details sd = new Service_Details();

            DbSet<Service_Details> obj = tr.Service_Details;

            var sql = from m in obj
                      where m.DeviceType == cmbBox.SelectedValue.ToString()
                      select m;

            Dg.ItemsSource = sql.ToList();
        }
    }
}
