﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Windows;
using EmployeeTravelBookingSystem.Exception;
using Entity;

namespace EmployeeTravelBookingSystem.DataAccessLayer
{
    public class BookingDAL
    {
        public BookingDAL()
        {
        }
        static string conStr = string.Empty;
        SqlConnection con = null;
        SqlCommand cmd = null;
      
        public bool AddEmployeeDAL(EmployeeDetails details)
        {
            bool result = false;
            try
            {
                conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                con = new SqlConnection(conStr);
                cmd = new SqlCommand();
                cmd.CommandText = "mini.addEmployee";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                cmd.Parameters.AddWithValue("@EmployeeId", details.EmployeeId);
                cmd.Parameters.AddWithValue("@Firstname", details.FirstName);
                cmd.Parameters.AddWithValue("@Lastname", details.LastName);
                cmd.Parameters.AddWithValue("@Age", details.Age);
                cmd.Parameters.AddWithValue("@Gender", details.Gender);
                cmd.Parameters.AddWithValue("@AddressofEmp", details.Address);
                cmd.Parameters.AddWithValue("@MobileNumber", details.MobileNumber);
                cmd.Parameters.AddWithValue("@EmailId", details.EmailId);
                cmd.Parameters.AddWithValue("@uname", details.UserName);
                cmd.Parameters.AddWithValue("@password", details.Password);
                cmd.Parameters.AddWithValue("@ManagerId", details.ManagerId);
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                if (noOfRowsAffected == 1)
                {
                    result = true;
                }
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
            return result;
        }

        public bool TicketRejectedDAL(int requestId)
        {
            try
            {
                conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                con = new SqlConnection(conStr);
                cmd = new SqlCommand();
                cmd.CommandText = "mini.updateStatusByTravelAgent";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                cmd.Parameters.AddWithValue("@RequestId", requestId);
                cmd.Parameters.AddWithValue("@Currentstatus", "Tickets Not available");
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                if (noOfRowsAffected == 1)
                {
                    return true;
                }
              
                    
                
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
            return false;
        }

        public DataTable DisplayPreviousRequestForAgentDAL()
        {
            DataTable dt = null;
            try
            {

                conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                con = new SqlConnection(conStr);
                cmd = new SqlCommand();
                cmd.CommandText = "mini.DisplayPreviousRequestsForAgent";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();


                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }

            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
            return dt;
        }

        public DataTable displayManagerRequestDAL(int mid)
        {
            DataTable dt = null;
            try
            {
               
                conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                con = new SqlConnection(conStr);
                cmd = new SqlCommand();
                cmd.CommandText = "mini.ManagerDisplay";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@ManagerId", mid);


                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);

                }
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
            return dt;
        }



        public DataTable DisplayRequestForAgentDAL()
        {
            DataTable dt = null;
            try
            {
                
                 conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                 con = new SqlConnection(conStr);
                 cmd = new SqlCommand();
                cmd.CommandText = "mini.DisplayRequestsForAgent";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();


                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
                
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
            return dt;
        }

        public bool TicketConfirmationDAL(int requestId)
        {


            try
            {
                conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                con = new SqlConnection(conStr);
                cmd = new SqlCommand();
                cmd.CommandText = "mini.updateStatusByTravelAgent";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                cmd.Parameters.AddWithValue("@RequestId", requestId);
                cmd.Parameters.AddWithValue("@Currentstatus", "Ticket Confirmed");
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                if (noOfRowsAffected == 1)
                {

                    return true;
                }
                
                    
               
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
            return false;
        }

        public bool AddAgentDAL(TravelAgentDetails agentDetails)
        {
            bool result = false;
            try
            {
                conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                con = new SqlConnection(conStr);
                cmd = new SqlCommand();
                cmd.CommandText = "mini.AddTravelAgent";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                cmd.Parameters.AddWithValue("@AgentName", agentDetails.agentName);
                cmd.Parameters.AddWithValue("@Username", agentDetails.agentUsername);
                cmd.Parameters.AddWithValue("@Password", agentDetails.agentPassword);
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                if (noOfRowsAffected == 1)
                {
                    result = true;
                }
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
            return result;
        }

        public DataTable GetMangerListDAL()
        {
            DataTable dt = null;

            try
            {
                conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                con = new SqlConnection(conStr);
                cmd = new SqlCommand();
                cmd.CommandText = "mini.GetManagersBYID";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            return dt;
        }

        public DataTable GetEmployeeListDAL()
        {
            DataTable dt = null;

            try
            {
                conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                con = new SqlConnection(conStr);
                cmd = new SqlCommand();
                cmd.CommandText = "mini.GetEmployeeBYID";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            return dt;
        }

        public bool MakeManagerDAL(int empId)
        {
            try
            {
                conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                con = new SqlConnection(conStr);
                cmd = new SqlCommand();
                cmd.CommandText = "mini.GetEmployeeBYID";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                cmd.Parameters.AddWithValue("@EmployeeId", empId);
                
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                if (noOfRowsAffected == 1)
                {

                    return true;
                }



            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
            return false;
        }

        public bool CancelTicketDAL(int requestid)
        {
            bool result = false;
            try
            {
                conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                con = new SqlConnection(conStr);
                cmd = new SqlCommand();
                cmd.CommandText = "mini.Cancelrequest";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                cmd.Parameters.AddWithValue("@RequestId", requestid);
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                if (noOfRowsAffected == 1)
                {
                    result = true;
                }
               
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
            return result;
        }

        public bool ApproveRequestDAL(int requestId)
        {

            try
            {
                conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                con = new SqlConnection(conStr);
                cmd = new SqlCommand();
                cmd.CommandText = "mini.updateStatusByManager";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                cmd.Parameters.AddWithValue("@RequestId", requestId);
                cmd.Parameters.AddWithValue("@Currentstatus", "Manager Approved");
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                if (noOfRowsAffected == 1)
                {
                    return true;
                }
               
                    
                
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
            return false;

        }

        public bool RejectRequestDAL(int requestId)
        {
            try
            {
                conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                con = new SqlConnection(conStr);
                cmd = new SqlCommand();
                cmd.CommandText = "mini.updateStatusByManager";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                cmd.Parameters.AddWithValue("@RequestId", requestId);
                cmd.Parameters.AddWithValue("@Currentstatus", "Manager Rejected");
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                if (noOfRowsAffected == 1)
                {
                    return true;
                }
                
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
            return false;

        }

        public DataTable displayEmpRequestDAL(int eid)
        {
            DataTable dt = null;
            try
            {
                
                conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                con = new SqlConnection(conStr);
                cmd = new SqlCommand();
                cmd.CommandText = "mini.DisplayEmpRequest";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                
                cmd.Parameters.AddWithValue("@EmployeeId", eid);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
               
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
            return dt;
        }

        public bool AddTicketDAL(TravelRequest raiseTicket)
        {
            bool result = false;
            try
            {

                
                conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                con = new SqlConnection(conStr);
                cmd = new SqlCommand();
                cmd.CommandText = "mini.bookingRequest";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                cmd.Parameters.Add("@RequestId", SqlDbType.Int);
                cmd.Parameters["@RequestId"].Direction = ParameterDirection.Output;
                cmd.Parameters.AddWithValue("@requestDate", raiseTicket.RequestDate);
                cmd.Parameters.AddWithValue("@FromLocation", raiseTicket.FromLocation);
                cmd.Parameters.AddWithValue("@ToLocation", raiseTicket.ToLocation);
                cmd.Parameters.AddWithValue("@EmployeeId", raiseTicket.EmployeeId);
                cmd.Parameters.AddWithValue("@ManagerId", raiseTicket.ManagerId);

                int noOfRowsAffected = cmd.ExecuteNonQuery();
                if (noOfRowsAffected == 1)
                {
                    result = true;
                }
              
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }


            finally
            {
                con.Close();
            }
            return result;

        }

    public bool UpdateManagerDAL(EmployeeDetails details)
        {
            bool result = false;
            try
            {
               
                 conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                 con = new SqlConnection(conStr);
                 cmd = new SqlCommand();
                cmd.CommandText = "mini.AssignManager1";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                cmd.Parameters.AddWithValue("@EmployeeId", details.EmployeeId);
                cmd.Parameters.AddWithValue("@ManagerId", details.ManagerId);
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                if (noOfRowsAffected == 1)
                {
                    result = true;
                }
                
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
            return result;
        }



        public bool DeleteEmployeeDAL(int delemp)
        {
            bool result = false;
            try
            {
               
                 conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
               con = new SqlConnection(conStr);
                 cmd = new SqlCommand();
                cmd.CommandText = "mini.DeleteEmployee";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                cmd.Parameters.AddWithValue("@EmployeeId", delemp);
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                if (noOfRowsAffected == 1)
                {
                    result = true;
                }
               
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
            return result;
        }
    }
}