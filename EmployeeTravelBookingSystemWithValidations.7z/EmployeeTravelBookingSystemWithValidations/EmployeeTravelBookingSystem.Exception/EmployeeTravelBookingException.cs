﻿using System;
using System.Runtime.Serialization;

namespace EmployeeTravelBookingSystem.Exception
{
    [Serializable]
    public class EmployeeTravelBookingException : ApplicationException
    {
        public EmployeeTravelBookingException()
        {
        }

        public EmployeeTravelBookingException(string message) : base(message)
        {
        }

        public EmployeeTravelBookingException(string message, System.Exception innerException) : base(message, innerException)
        {
        }

        protected EmployeeTravelBookingException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}