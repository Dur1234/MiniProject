﻿using EmployeeTravelBookingSystem.BussinessLayer;
using Entity;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EmployeeTravelBookingSystem
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public string  pass;
        public string user;
        public string managerUser;
        public string password;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            CanvasTravelAgent.Visibility = Visibility.Hidden;
            CanvasManager.Visibility = Visibility.Hidden;
            CanvasEmployee.Visibility = Visibility.Hidden;
            CanvasAdmin.Visibility = Visibility.Visible;
        }

        private void btnAdminLogin_Click(object sender, RoutedEventArgs e)
        {
            //try
            //{
            //    string username = txtAdminId.Text;
            //    string password = pwdAdminPassword.Password;
            //    BookingBL bbl = new BookingBL(); 


            //}
            try
            {
                using (SqlConnection sqlcon = new SqlConnection(ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString))
                {
                    string query = $"select count(1) from mini.AdminLogin where AdminUsername='" + txtAdminId.Text + "' AND AdminPass='" + pwdAdminPassword.Password + "'";
                    SqlCommand cmd = new SqlCommand(query, sqlcon);
                    sqlcon.Open();


                    int count = Convert.ToInt32(cmd.ExecuteScalar());
                    if (count == 1)
                    {
                        AdminForm newWindow = new AdminForm();
                        newWindow.Show();
                        txtAdminId.Text = "";
                        pwdAdminPassword.Password = "";
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Invalid login credentials");

                    }

                }
            }
            catch (SystemException)
            {

                throw;
            }
        }

        private void textBox_Copy_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            CanvasTravelAgent.Visibility = Visibility.Hidden;
            CanvasManager.Visibility = Visibility.Hidden;
            CanvasAdmin.Visibility = Visibility.Hidden;
            CanvasEmployee.Visibility = Visibility.Visible;
        }

        private void MenuItem_Click_2(object sender, RoutedEventArgs e)
        {
            CanvasTravelAgent.Visibility = Visibility.Hidden;
            CanvasEmployee.Visibility = Visibility.Hidden;
            CanvasAdmin.Visibility = Visibility.Hidden;
            CanvasManager.Visibility = Visibility.Visible;
        }

        private void MenuItem_Click_3(object sender, RoutedEventArgs e)
        {
            CanvasEmployee.Visibility = Visibility.Hidden;
            CanvasAdmin.Visibility = Visibility.Hidden;
            CanvasManager.Visibility = Visibility.Hidden;
            CanvasTravelAgent.Visibility = Visibility.Visible;
        }

        private void btnEmployeeLogin_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using (SqlConnection sqlcon = new SqlConnection(ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString))
                {
                    string query = $"select count(1) from mini.EmployeeDetails where username='" + txtEmployeeLogin.Text + "' AND password='" + pwdEmpPassword.Password + "'";
                    SqlCommand cmd = new SqlCommand(query, sqlcon);
                    sqlcon.Open();
                   
                    user = txtEmployeeLogin.Text.ToString();
                    pass = pwdEmpPassword.Password;
                    int count = Convert.ToInt32(cmd.ExecuteScalar());
                    if (count == 1)
                    {

                        EmployeeForm newWindow = new EmployeeForm(user, pass);
                        newWindow.Show();
                        txtEmployeeLogin.Text = "";
                        pwdEmpPassword.Password = "";
                    }
                    else
                    {
                        MessageBox.Show("Invalid login credentials");
                    }
                }
            }
            catch (SystemException ex)
            {

                MessageBox.Show(ex.Message);  
            }      
        }


        private void btnManagerLogin_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                string conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                SqlConnection con = new SqlConnection(conStr);
                SqlCommand cmd = new SqlCommand($"select * from mini.ManagerLogin where Username ='" + txtManagerLogin.Text + "' and password ='" + pwdManagerPassword.Password + "'", con);
                con.Open();
                user = txtManagerLogin.Text;
                password = pwdManagerPassword.Password;
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    
                    var manager = new ManagerPage(user, password);
                    manager.Show();
                    txtManagerLogin.Text = "";
                    pwdManagerPassword.Password = "";
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Invalid Credentials");
                }
            }
            catch (SystemException ex)
            {

                MessageBox.Show(ex.Message);
            }

        }


        private void btnTravelAgentLogin_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                string conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                SqlConnection con = new SqlConnection(conStr);
                SqlCommand cmd = new SqlCommand($"select * from mini.Agentlogin where AgentUsername ='" + txtTravelAgentLogin.Text + "' and AgentPass ='" + pwdAgent.Password + "'", con);
                con.Open();
                user = txtManagerLogin.Text;
                password = pwdAgent.Password;
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();

                    TravelAgent taf = new TravelAgent();
                    taf.Show();
                    txtTravelAgentLogin.Text = "";
                    pwdAgent.Password = "";
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Invalid Credentials");
                }
            }
            catch (SystemException ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
           
  
       

        private void MenuItem_Click_4(object sender, RoutedEventArgs e)
        {

        }

        private void MenuItem_Click_5(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
